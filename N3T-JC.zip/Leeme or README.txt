Para abrir el programa abran el archivo "N3T-JC.exe" o "N3T-JC"
For open the software ,open file  "N3T-JC.exe" o "N3T-JC"

N3T-JC es un programa informatico desarrollado
por FranckeyJC "Franckey Castro" para acelerar el internet 
mediante modificaciones que se le hace a las DNS y el TCP/IP 
entre otras configuraciones que se hacen para mejorar el
rendimiento del INTERNET INALAMBRICO "WIFI" y INTERNET 
CABLEADO "ETHERNET" con solo dar click al boton "BOOST"
Nota:para usar el tema light cambia el nombre del archivo "dark.txt" a 
"light.txt".

N3T JC is an software developed program by FranckeyJC "Franckey Castro"
to accelerate the internet By means of modifications that DNS and 
the TCP/IP are done to him to them Enter another configurations
that they are done for the better the Performance of the 
WIRELESS INTERNET "WIFI" and INTERNET
WIRED "ETHERNET" with solo giving click in vain BOOST
See :Light Skin in order to use the theme the name of the file "dark.txt" to
"Light.txt".